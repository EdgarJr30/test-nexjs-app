const Socials = () => {
  return <div>Socials</div>;
};

export default Socials;
