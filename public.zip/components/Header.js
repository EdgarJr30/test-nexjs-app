const Header = () => {
  return <header className="absolute z-30 w-full">Header</header>;
};

export default Header;
