const Testimonials = () => {
  return <div>Testimonials</div>;
};

export default Testimonials;
